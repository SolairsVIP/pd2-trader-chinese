import { runeWords, setItems, uniqueItems } from '@/assets/items';
import { modifierByName } from '@/assets/modifiers';
import { SITE_BASE_NAMES, SITE_ITEM_TYPES } from './catalog.data';
import { statLabel } from './stats';
import type { CharClass, CorruptionOption, Rarity } from './types';

export interface CatalogOption {
  /** Query value: a type/base code, or the site's JSON `{"$in": [...]}` string for grouped entries. */
  code: string;
  label: string;
}

const TYPE_LABELS_ZH: Record<string, string> = {
  '2H Crystal Sword': '双手水晶剑',
  'Amazon Bow': '亚马逊弓',
  'Amazon Javelin': '亚马逊标枪',
  'Amazon Spear': '亚马逊长矛',
  Armor: '护甲',
  Axe: '斧头',
  'Barbarian Helm': '野蛮人头盔',
  Belt: '腰带',
  Boots: '靴子',
  Bow: '弓',
  'Bow Quiver': '弓箭袋',
  Charm: '护身符',
  Circlet: '头环',
  Club: '木棒',
  'Craft Ingredient': '手工材料',
  Crossbow: '弩',
  'Crossbow Quiver': '弩箭袋',
  Dagger: '匕首',
  'Druid Pelt': '德鲁伊头饰',
  'Fist Weapon': '拳套',
  Gem: '宝石',
  Gloves: '手套',
  Hammer: '锤子',
  Helm: '头盔',
  'ImbueMag Ready': '可注入魔法物品',
  'ImbueRandom Ready': '可随机注入物品',
  'ImbueRare Ready': '可注入稀有物品',
  Javelin: '标枪',
  Jewel: '珠宝',
  'Jewel Fragments': '珠宝碎片',
  Jewelry: '首饰',
  Key: '钥匙',
  'Large Charm PVP': '大型 PvP 护身符',
  "Larzuks Malus": '拉苏克的惩罚',
  Mace: '钉头锤',
  'Map Orb': '地图宝珠',
  'Map T1': 'T1 地图',
  'Map T2': 'T2 地图',
  'Map T3': 'T3 地图',
  'Map T4': 'T4 地图',
  'Map T5': 'T5 地图',
  'Medium Charm PVP': '中型 PvP 护身符',
  'Paladin Shield': '圣骑士盾牌',
  Polearm: '长柄武器',
  Puzzlebox: '拼图盒',
  Puzzlepiece: '拼图碎片',
  'Pvp Map Desert': 'PvP 沙漠地图',
  'RerollRare Ready': '可重掷稀有物品',
  Rune: '符文',
  Scepter: '权杖',
  Scythe: '镰刀',
  Shield: '盾牌',
  'Shrunken Head': '缩小的头颅',
  'Small Charm PVP': '小型 PvP 护身符',
  'Sorceress Orb': '女巫法球',
  Spear: '长矛',
  Staff: '法杖',
  Sword: '剑',
  'Throwing Axe': '飞斧',
  'Throwing Knife': '飞刀',
  Token: '代币',
  'Torch Fragment': '火炬碎片',
  'Uber Ingredient': '超级首领材料',
  'Uber Unique': '超级暗金物品',
  'UpgradeMag Ready': '可升级魔法物品',
  Wand: '魔杖',
  'Worldstone Shard': '世界之石碎片',
};

/** The site's Type select (without "Any"), sorted by label. */
export const ITEM_TYPES: CatalogOption[] = SITE_ITEM_TYPES.map(({ code, label }) => ({
  code,
  label: TYPE_LABELS_ZH[label] ?? label,
}));

const BASES_BY_TYPE = new Map(SITE_ITEM_TYPES.map((t) => [t.code, t.bases]));

/** The site's Base select for a Type (sorted by label); empty for an unknown type. */
export function basesForType(typeCode: string | undefined): CatalogOption[] {
  return typeCode ? [...(BASES_BY_TYPE.get(typeCode) ?? [])] : [];
}

/** Codes a type/base option stands for: its own code, or every member of a `{"$in": [...]}` group. */
export function optionCodes(code: string): string[] {
  if (!code.startsWith('{')) return [code];
  try {
    const parsed = JSON.parse(code) as { $in?: unknown };
    return Array.isArray(parsed.$in) ? parsed.$in.filter((c): c is string => typeof c === 'string') : [];
  } catch {
    return [];
  }
}

/**
 * The Type and Base select values for an item base (`item.base_code`, e.g. `uap` → Helm / Shako's base), so
 * "Open in market" can preselect them. Null when the site doesn't offer the base.
 */
export function findBaseOption(baseCode: string): { typeCode: string; baseCode: string } | null {
  for (const type of SITE_ITEM_TYPES) {
    const base = type.bases.find((b) => b.code === baseCode || optionCodes(b.code).includes(baseCode));
    if (base) return { typeCode: type.code, baseCode: base.code };
  }
  return null;
}

/** Type option for a raw `item.base.type_code` (grouped types such as Jewelry/Charm resolve to the group). */
export function findTypeOption(typeCode: string): CatalogOption | null {
  return ITEM_TYPES.find((t) => t.code === typeCode || optionCodes(t.code).includes(typeCode)) ?? null;
}

export const RARITIES: Rarity[] = ['Normal', 'Superior', 'Magic', 'Rare', 'Crafted', 'Set', 'Unique', 'Runeword'];

export const CLASSES: { value: CharClass; label: string }[] = [
  { value: 'amazon', label: '亚马逊' },
  { value: 'assassin', label: '刺客' },
  { value: 'barbarian', label: '野蛮人' },
  { value: 'druid', label: '德鲁伊' },
  { value: 'necromancer', label: '死灵法师' },
  { value: 'paladin', label: '圣骑士' },
  { value: 'sorceress', label: '女巫' },
];

/**
 * Values seen in live `item.corruptions` (modifier names of the corruption roll), most common first. Labels
 * are the property templates without the roll. `dmg%` is left out: it always comes with `maxdamage_percent`.
 */
const CORRUPTION_KEYS = [
  'item_numsockets',
  'maxdamage_percent',
  'item_fastercastrate',
  'item_allskills',
  'all_resist',
  'fireresist',
  'coldresist',
  'lightresist',
  'poisonresist',
  'maxfireresist',
  'maxcoldresist',
  'maxlightresist',
  'maxpoisonresist',
  'item_fasterattackrate',
  'item_fastergethitrate',
  'item_fastermovevelocity',
  'item_magicbonus',
  'item_goldbonus',
  'item_deadlystrike',
  'item_crushingblow',
  'item_manaafterkill',
  'item_healafterkill',
  'item_healafterhit',
  'lifedrainmindam',
  'manadrainmindam',
  'tohit',
  'strength',
  'dexterity',
  'vitality',
  'energy',
  'maxhp',
  'item_maxhp_percent',
  'item_armor_percent',
  'damageresist',
  'normal_damage_reduction',
  'magic_damage_reduction',
  'toblock',
  'item_fasterblockrate',
  'item_cannotbefrozen',
  'item_pierce',
  'item_ignoretargetac',
  'passive_fire_pierce',
  'passive_cold_pierce',
  'passive_ltng_pierce',
  'passive_pois_pierce',
  'hpregen',
  'manarecoverybonus',
  'curse_resistance',
  'item_req_percent',
  'item_lightradius',
  'dmg-max',
  'curse_effectiveness',
  'item_thorns_perlevel',
  'passive_fire_mastery',
  'passive_cold_mastery',
  'passive_ltng_mastery',
  'passive_pois_mastery',
  'item_demon_tohit',
  'item_demondamage_percent',
  'item_undead_tohit',
  'item_undeaddamage_percent',
  'item_fractionaltargetac',
  'item_damagetargetac',
  'maxmana',
  'item_addexperience',
];

const CORRUPTION_LABELS: Record<string, string> = {
  item_numsockets: '孔数',
  transform_dye: '染色',
  indestruct: '无法损坏',
};

/**
 * Corruptions without a `corrupted` modifier line of their own, so nothing to bound (the market service rejects
 * min/max on them): sockets, the `dmg%` / `dmg-max` markers, dye and indestructible.
 */
const UNROLLED_CORRUPTIONS = new Set(['item_numsockets', 'dmg%', 'dmg-max', 'transform_dye', 'indestruct']);

/** Corruption values that aren't property keys, mapped to the property they roll. */
const CORRUPTION_PROPERTY: Record<string, string> = {
  'dmg-max': 'max_damage|maxdamage|secondary_maxdamage|item_throw_maxdamage',
};

/** The property's label template (else the modifier's own label) without the roll. */
function corruptionLabel(value: string): string {
  if (CORRUPTION_LABELS[value]) return CORRUPTION_LABELS[value];
  const key = CORRUPTION_PROPERTY[value] ?? value;
  const template = statLabel(key);
  const modLabel = modifierByName[key]?.description?.label;
  const own = modLabel && 'positive' in modLabel ? modLabel.positive : undefined;
  const text = template !== key ? template : (own ?? key);
  return text
    .replace(/[+-]?\{X\}%?/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export const CORRUPTION_OPTIONS: CorruptionOption[] = [...CORRUPTION_KEYS, 'transform_dye', 'indestruct'].map(
  (value) => ({ value, label: corruptionLabel(value), rolled: !UNROLLED_CORRUPTIONS.has(value) }),
);

const CORRUPTION_BY_VALUE = new Map(CORRUPTION_OPTIONS.map((o) => [o.value, o]));

/** The picker entry of a corruption name; unknown names (older saved searches) are labelled by the name. */
export function corruptionOption(value: string): CorruptionOption {
  return CORRUPTION_BY_VALUE.get(value) ?? { value, label: value, rolled: !UNROLLED_CORRUPTIONS.has(value) };
}

export interface ItemNameOption {
  name: string;
  quality: 'Unique' | 'Set' | 'Runeword' | 'Base';
  /** Equipment slot / type for the suggestion ("Helm", "Ring", "Bow"); absent for runewords and unknown bases. */
  slot?: string;
}

/** Catalog types named by their member base instead ("Ring" rather than "Jewelry"). */
const SLOT_BY_BASE_NAME: Record<string, true> = { Jewelry: true };
const SLOT_RENAMES: Record<string, string> = { Armor: '护甲' };

/** Base code and base name → slot label, from the site's Type/Base catalog. */
const SLOTS: Map<string, string> = (() => {
  const map = new Map<string, string>();
  for (const type of SITE_ITEM_TYPES) {
    for (const base of type.bases) {
      const slot = SLOT_BY_BASE_NAME[type.label]
        ? base.label === 'Ring'
          ? '戒指'
          : base.label === 'Amulet'
            ? '项链'
            : base.label
        : (SLOT_RENAMES[type.label] ?? TYPE_LABELS_ZH[type.label] ?? type.label);
      for (const code of optionCodes(base.code)) if (!map.has(code)) map.set(code, slot);
      if (!map.has(base.label)) map.set(base.label, slot);
    }
  }
  return map;
})();

/** Slot label, or undefined when it would only repeat the name ("Ring" for Ring). */
function slotFor(key: string | undefined, name: string): string | undefined {
  const slot = key ? SLOTS.get(key) : undefined;
  return slot && slot !== name ? slot : undefined;
}

/** The site's item-name autocomplete: uniques, sets, runewords, then bases and a few misc items. */
const ITEM_NAMES: ItemNameOption[] = (() => {
  const seen = new Set<string>();
  const out: ItemNameOption[] = [];
  const add = (name: string | undefined, quality: ItemNameOption['quality'], slot?: string) => {
    if (!name || seen.has(name)) return;
    seen.add(name);
    out.push(slot ? { name, quality, slot } : { name, quality });
  };
  for (const item of uniqueItems) add(item.name, 'Unique', slotFor(item.base_code, item.name));
  for (const item of setItems) add(item.name, 'Set', slotFor(item.base_code, item.name));
  for (const item of runeWords) add(item.name, 'Runeword');
  for (const name of SITE_BASE_NAMES) add(name, 'Base', slotFor(name, name));
  for (const name of [
    'Horadric Navigator',
    'Horadric Almanac',
    'Skeleton Key',
    'Full Rejuvenation Potion',
    'Standard of Heroes',
  ]) {
    add(name, 'Base');
  }
  return out;
})();

/**
 * Item names matching `query` (case-insensitive): prefix matches, then word-start matches, then substring
 * matches; alphabetical within each.
 */
export function itemNameOptions(query: string, limit = 30): ItemNameOption[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const ranked: { option: ItemNameOption; rank: number }[] = [];
  for (const option of ITEM_NAMES) {
    const name = option.name.toLowerCase();
    const at = name.indexOf(q);
    if (at < 0) continue;
    ranked.push({ option, rank: at === 0 ? 0 : /[\s'-]/.test(name[at - 1]) ? 1 : 2 });
  }
  return ranked
    .sort((a, b) => a.rank - b.rank || a.option.name.localeCompare(b.option.name))
    .slice(0, limit)
    .map((r) => r.option);
}
