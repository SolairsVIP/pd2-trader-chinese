import React, { useState } from 'react';
import { ChevronDown, Copy, HandCoins } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { showToast } from '@/overlay';
import type { MarketListingEntry } from '@/common/types/pd2-website/GetMarketListingsResponse';
import type { ListingActions } from '../hooks/useListingActions';
import type { MarketApi } from '../lib/types';
import { NumberInput, fieldInputClass } from './controls';

/** Icon-only action button (tooltip via title). */
export const iconActionClass = 'size-7 p-0 text-muted-foreground hover:text-foreground';

/**
 * Make offer: the site's offer form (offer text + optional HR value) in a popover; the website without
 * createOffer. `ensureFresh` re-checks the listing on PD2 before sending (useListingActions). `dense`: card
 * footer size. `openNonce`: a changed value opens the form (the card's O hotkey).
 */
export function OfferButton({
  api,
  listing,
  onWebsite,
  ensureFresh,
  dense = false,
  openNonce,
}: {
  api: MarketApi | null;
  listing: MarketListingEntry;
  onWebsite: () => void;
  ensureFresh: ListingActions['ensureFresh'];
  dense?: boolean;
  openNonce?: number;
}) {
  const [open, setOpen] = useState(false);
  const [price, setPrice] = useState('');
  const [hr, setHr] = useState<number | undefined>(undefined);
  const [sending, setSending] = useState(false);
  const createOffer = api?.createOffer;
  const label = createOffer ? '发起报价' : '前往网站报价';
  // Adjusted during render: a new hotkey press opens the form (or the website without createOffer)
  const [seenNonce, setSeenNonce] = useState(openNonce);
  if (openNonce !== seenNonce) {
    setSeenNonce(openNonce);
    if (openNonce !== undefined && createOffer) setOpen(true);
  }
  const button = (
    <Button
      size="sm"
      className={dense ? 'h-7 px-2.5 text-xs' : 'h-8 text-xs'}
      onClick={createOffer ? undefined : onWebsite}
    >
      <HandCoins className="size-3.5" />
      {label}
    </Button>
  );
  if (!createOffer) return button;

  const submit = async () => {
    if (!price.trim() || sending) return;
    setSending(true);
    try {
      // Gone or repriced since it was shown: the toast says so; a repeat send after a change goes ahead
      if (!(await ensureFresh())) return;
      const created = await createOffer(listing._id, { price: price.trim(), hrPrice: hr && hr > 0 ? hr : undefined });
      if (created === null) return; // 401: the sign-in flow takes over
      showToast({ title: '报价已发送', description: `为「${listing.item.name}」报价 ${price.trim()}`, variant: 'success' });
      setOpen(false);
      setPrice('');
      setHr(undefined);
    } catch (e) {
      showToast({
        title: '报价未发送',
        description:
          e instanceof Error && /[\u3400-\u9fff]/.test(e.message)
            ? e.message.split('\n')[0]
            : 'Project Diablo 2 未能接受这份报价，请稍后重试。',
        variant: 'error',
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Popover open={open}
      onOpenChange={setOpen}>
      <PopoverTrigger asChild>{button}</PopoverTrigger>
      <PopoverContent side="top"
        align="start"
        className="w-72 p-2.5">
        <form
          className="space-y-1.5"
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
        >
          <div className="text-xs font-semibold">{`为「${listing.item.name}」报价`}</div>
          {listing.price && (
            <div className="truncate text-[11px] text-muted-foreground">{`卖家标价：${listing.price}`}</div>
          )}
          <Input
            autoFocus
            aria-label="报价内容"
            placeholder="输入报价，例如：2 Ist + Um"
            maxLength={120}
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className={fieldInputClass}
          />
          <label className="flex items-center gap-2 text-[11px] text-muted-foreground">
            <span className="shrink-0">估值（HR，可选）</span>
            <NumberInput
              ariaLabel="报价折合 HR 数量"
              value={hr}
              step={0.1}
              min={0}
              onChange={setHr}
              placeholder="例如：1.5"
            />
          </label>
          <Button type="submit"
            size="sm"
            className="h-7 w-full text-xs"
            disabled={!price.trim() || sending}>
            {sending ? '发送中…' : '发送报价'}
          </Button>
        </form>
      </PopoverContent>
    </Popover>
  );
}

/** Whisper (copy) with a menu of the user's chat templates; `dense`: the card footer's outline style. */
export function WhisperButton({ actions, dense = false }: { actions: ListingActions; dense?: boolean }) {
  const { copyWhisper, whisperTemplates } = actions;
  const variant = dense ? 'outline' : 'secondary';
  return (
    <div className="flex min-w-0">
      <Button
        variant={variant}
        size="sm"
        className={cn('flex-1 rounded-r-none text-xs', dense ? 'h-7 px-2.5' : 'h-8')}
        title="复制游戏密语（W）"
        onClick={() => void copyWhisper()}
      >
        <Copy className="size-3.5" />
        游戏密语
      </Button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant={variant}
            size="sm"
            className={cn('rounded-l-none border-l-0 p-0', dense ? 'h-7 w-5' : 'h-8 w-6 border-l border-border/60')}
            aria-label="使用模板发送游戏密语"
            title="使用模板发送游戏密语"
          >
            <ChevronDown className="size-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end"
          className="w-60">
          <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-muted-foreground">
            使用聊天模板发送游戏密语
          </DropdownMenuLabel>
          {whisperTemplates.length === 0 && (
            <DropdownMenuItem disabled
              className="text-xs">
              暂无模板（设置 → 聊天）
            </DropdownMenuItem>
          )}
          {whisperTemplates.map((t) => (
            <DropdownMenuItem key={t.id}
              className="text-xs"
              onSelect={() => void copyWhisper(t.text)}>
              <span className="min-w-0 flex-1 truncate">{t.name}</span>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
