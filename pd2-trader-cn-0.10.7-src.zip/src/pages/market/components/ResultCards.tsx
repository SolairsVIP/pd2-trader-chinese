import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { motion } from 'framer-motion';
import { DUR, EASE_OUT } from '@/lib/motion';
import { Bell, Clock, ExternalLink, Gamepad2, Heart, MessageSquare, Shield, Sigma, Swords, X } from 'lucide-react';
import { isUserOnlineIngame } from '@/lib/user-online-status';
import { cn } from '@/lib/utils';
import { localizePd2Text, localizeQuality } from '@/lib/localize-pd2-text';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { ListingThumb } from '@/pages/chat/components/ListingCard';
import { useListingMarketPrices } from '@/pages/chat/hooks/useListingMarketPrices';
import { DealBadge } from '@/pages/market/enrich/DealBadge';
import type { Deal } from '@/pages/market/enrich/useDealIndicators';
import type { ItemDetail, MarketListingEntry } from '@/common/types/pd2-website/GetMarketListingsResponse';
import type { JewelElement } from '@/pages/chat/lib/listing-art';
import { useListingActions } from '../hooks/useListingActions';
import { buildCardModel, modMatchesStatKey, type CardMod, type SocketGroup } from '../lib/card-model';
import { listingAge, sellerAccount } from '../lib/listing';
import type { MarketApi, ScoredListing } from '../lib/types';
import { itemNameColor } from './ItemTooltip';
import { OfferButton, WhisperButton, iconActionClass } from './ListingActions';
import { LoadMoreFooter, type LoadMoreState, OnlineDots, formatHrPrice } from './ResultsList';
import { formatStat, statWithValue } from './stat-text';
import { AddAllModsButton, ModMenu } from './ModMenu';
import { EnterOnce, type EnterTracker } from './EnterOnce';
import type { AlertGlow } from '../hooks/useLiveAlertGlow';

const ESTIMATED_CARD_HEIGHT = 340;
const GAP = 8;
const PADDING = 8;
/** Cards from the end at which the next server page is requested. */
const LOAD_MORE_AHEAD = 3;

/** A hotkey for the selected card (O offer, W whisper, F favorite); `nonce` makes repeats distinct. */
export interface CardCommand {
  id: string;
  action: 'offer' | 'whisper' | 'favorite';
  nonce: number;
}

/** An alert listing pinned at the top of the cards ("From alert: <search>"). */
export interface CardPin {
  id: string;
  searchName?: string;
  onDismiss: () => void;
}

export interface ResultCardsProps {
  rows: ScoredListing[];
  selectedId: string | null;
  /** Click: select (the card is self-contained; no detail pane needed). */
  onSelect: (listingId: string) => void;
  deals: ReadonlyMap<string, Deal>;
  pseudoKeys: string[];
  /** Enabled mod filter keys: matching lines are marked. */
  statKeys: string[];
  favoriteIds: Set<string>;
  onToggleFavorite: (listing: MarketListingEntry) => void;
  /** Sold archive: no offer/whisper. */
  archived: boolean;
  api: MarketApi | null;
  command: CardCommand | null;
  /** Claims a command nonce for running (true once per nonce; see useCardCommand). */
  takeCommand: (nonce: number) => boolean;
  /** An alert's listing pinned above the results (not in them): labelled and dismissable. */
  pinned?: CardPin | null;
  /** Listings that just matched a live alert of this (watched) search: a one-time soft glow. */
  glowIds: AlertGlow;
  /** Entrance animations of this result set (cards enter once; see EnterOnce). */
  enter: EnterTracker;
  hasMore: boolean;
  loadingMore: boolean;
  onLoadMore: () => void;
  /** A failed next page: the footer offers Retry instead of loading on scroll. */
  loadMore: LoadMoreState;
}

/** Full-width result cards, one per row, virtualized (cards vary in height, so each is measured). */
export function ResultCards({
  rows,
  selectedId,
  onSelect,
  deals,
  pseudoKeys,
  statKeys,
  favoriteIds,
  onToggleFavorite,
  archived,
  api,
  command,
  takeCommand,
  pinned,
  glowIds,
  enter,
  hasMore,
  loadingMore,
  onLoadMore,
  loadMore,
}: ResultCardsProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  /** Glows already played (`nonce:id`): a card scrolled back into view doesn't glow again. */
  const playedGlows = useRef(new Set<string>());
  // eslint-disable-next-line react-hooks/incompatible-library -- no React Compiler; the virtualizer re-renders us
  const virtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () =>
      containerRef.current?.querySelector<HTMLDivElement>('[data-slot="scroll-area-viewport"]') ?? null,
    estimateSize: () => ESTIMATED_CARD_HEIGHT,
    getItemKey: (index) => rows[index].listing._id,
    overscan: 3,
    paddingStart: PADDING,
    paddingEnd: PADDING,
    gap: GAP,
  });

  // Keep the keyboard selection in view
  const selectedIndex = selectedId ? rows.findIndex((r) => r.listing._id === selectedId) : -1;
  useEffect(() => {
    if (selectedIndex >= 0) virtualizer.scrollToIndex(selectedIndex, { align: 'auto' });
  }, [selectedIndex, virtualizer]);

  useEffect(() => {
    virtualizer.scrollToOffset(0);
  }, [enter.generation, virtualizer]);

  // Infinite load: the last rendered card is near the end
  const lastVisible = virtualizer.getVirtualItems().at(-1)?.index ?? -1;
  useEffect(() => {
    if (hasMore && !loadingMore && rows.length > 0 && lastVisible >= rows.length - LOAD_MORE_AHEAD) onLoadMore();
  }, [hasMore, loadingMore, lastVisible, rows.length, onLoadMore]);

  return (
    <ScrollArea
      ref={containerRef}
      className="min-h-0 flex-1 overflow-hidden [&_[data-radix-scroll-area-viewport]>div]:!block"
    >
      <div
        role="listbox"
        aria-label="挂单列表"
        className="relative w-full"
        style={{ height: virtualizer.getTotalSize() }}
      >
        {virtualizer.getVirtualItems().map((item) => {
          const row = rows[item.index];
          const id = row.listing._id;
          return (
            <div
              key={`${enter.generation}:${item.key}`}
              ref={virtualizer.measureElement}
              data-index={item.index}
              className="absolute left-0 top-0 w-full"
              style={{ transform: `translateY(${item.start}px)`, paddingInline: PADDING }}
            >
              <EnterOnce tracker={enter}
                id={id}
                index={item.index}
                className="relative">
                <ResultCard
                  row={row}
                  selected={id === selectedId}
                  onSelect={onSelect}
                  deal={deals.get(id)}
                  pseudoKeys={pseudoKeys}
                  statKeys={statKeys}
                  favorite={favoriteIds.has(id)}
                  onToggleFavorite={onToggleFavorite}
                  archived={archived}
                  api={api}
                  // Only the selected card gets hotkeys (the others keep their memoized props)
                  command={command && command.id === id ? command : null}
                  takeCommand={takeCommand}
                  pin={pinned && pinned.id === id ? pinned : null}
                />
                {glowIds.ids.has(id) && (
                  <GlowOnce
                    key={`${glowIds.nonce}:${id}`}
                    glowKey={`${glowIds.nonce}:${id}`}
                    played={playedGlows.current}
                  />
                )}
              </EnterOnce>
            </div>
          );
        })}
      </div>
      <LoadMoreFooter loading={loadingMore}
        {...loadMore} />
    </ScrollArea>
  );
}

/** A soft accent glow over a card that just matched a live alert; plays once per alert (not on remount). */
function GlowOnce({ glowKey, played }: { glowKey: string; played: Set<string> }) {
  const [show] = useState(() => !played.has(glowKey));
  useEffect(() => {
    played.add(glowKey);
  }, [played, glowKey]);
  if (!show) return null;
  return (
    <motion.span
      aria-hidden
      className="pointer-events-none absolute inset-0 rounded-lg bg-primary/5 ring-2 ring-primary/50"
      initial={{ opacity: 0 }}
      animate={{ opacity: [0, 1, 1, 0] }}
      transition={{ duration: 2.4, times: [0, 0.12, 0.55, 1], ease: 'easeOut' }}
    />
  );
}

/** "Ohm" for "Ohm Rune"; jewels and gems keep their name. */
const shortName = (name: string) => name.replace(/ Rune$/, '');
/** Most socket icons a breakdown stacks (the tooltip lists every source). */
const MAX_STACK_ICONS = 6;

/** Rainbow Facet names in their element's colour (the game's elemental hues; themes have no element tokens). */
const ELEMENT_TEXT: Record<JewelElement, string> = {
  fire: 'text-[#ff7043]',
  cold: 'text-[#6aa8ff]',
  lightning: 'text-[#f2cf4a]',
  poison: 'text-[#62c75f]',
};
const groupNameColor = (group: SocketGroup) =>
  group.element ? ELEMENT_TEXT[group.element] : itemNameColor(group.items[0]);

/** A socketable's art in a small ring; `className` overrides the 14px size. */
function SocketIcon({ listing, className }: { listing: MarketListingEntry; className?: string }) {
  return (
    <ListingThumb
      listing={listing}
      className={cn('size-3.5 rounded-full border border-border bg-muted/80 shadow-none ring-1 ring-card', className)}
      artClassName="max-h-[85%] max-w-[85%]"
    />
  );
}

const pill = 'inline-flex h-5 items-center rounded-full border px-2 text-[10px] font-medium leading-none';

const ResultCard = React.memo(function ResultCard({
  row,
  selected,
  onSelect,
  deal,
  pseudoKeys,
  statKeys,
  favorite,
  onToggleFavorite,
  archived,
  api,
  command,
  takeCommand,
  pin,
}: {
  row: ScoredListing;
  selected: boolean;
  onSelect: (id: string) => void;
  deal: Deal | undefined;
  pseudoKeys: string[];
  statKeys: string[];
  favorite: boolean;
  onToggleFavorite: (listing: MarketListingEntry) => void;
  archived: boolean;
  api: MarketApi | null;
  command: CardCommand | null;
  takeCommand: (nonce: number) => boolean;
  pin: CardPin | null;
}) {
  const { listing } = row;
  const { item } = listing;
  const model = useMemo(() => buildCardModel(item), [item]);
  const actions = useListingActions(listing);
  const [hovered, setHovered] = useState<number | null>(null);

  // Socket prices (runes, priced uniques…) through the economy service, one pseudo-listing per group
  const groupListings = useMemo(
    () => model.groups.map((g, i) => ({ ...listing, _id: `${listing._id}#socket${i}`, item: g.items[0] })),
    [model.groups, listing],
  );
  const groupPrices = useListingMarketPrices(groupListings);
  const groupHr = (i: number) => {
    const price = groupPrices.get(groupListings[i]._id);
    return price ? price.hr * model.groups[i].items.length : null;
  };

  // Hotkeys for the selected card, each run once: the page hands out every command nonce once (takeCommand,
  // which also clears it), so a card that remounts can't replay it. O opens the offer form through the
  // nonce's change (OfferButton ignores the nonce it mounts with).
  useEffect(() => {
    if (!command || !takeCommand(command.nonce)) return;
    if (command.action === 'favorite') onToggleFavorite(listing);
    else if (command.action === 'whisper' && !archived) void actions.copyWhisper();
  }, [command, takeCommand, onToggleFavorite, listing, archived, actions]);

  const price = formatHrPrice(listing.hr_price);
  const quality = localizeQuality(item.is_runeword ? 'Runeword' : (item.quality?.name ?? ''));
  const handType = item.damage?.two_handed ? 'Two-Hand' : item.damage?.one_handed ? 'One-Hand' : null;
  const subtitle = [
    [quality, item.base?.name && item.base.name !== item.name ? item.base.name : null].filter(Boolean).join(' '),
    [handType, item.base?.type].filter(Boolean).join(' '),
  ]
    .filter(Boolean)
    .join(' · ');
  const req = item.requirements;
  const account = sellerAccount(listing) || listing.user?.username;

  return (
    <article
      role="option"
      aria-selected={selected}
      data-listing-id={listing._id}
      onClick={() => onSelect(listing._id)}
      className={cn(
        'cursor-default overflow-hidden rounded-lg border bg-foreground/[0.015] transition-colors duration-(--dur-fast)',
        selected ? 'border-primary' : 'border-border/60 hover:border-border',
        pin && 'ring-2 ring-primary/30',
      )}
    >
      {pin && (
        <div className="flex items-center gap-1.5 border-b border-primary/30 bg-primary/10 px-3 py-1 text-[11px] text-primary">
          <Bell className="size-3 shrink-0" />
          <span className="min-w-0 flex-1 truncate">
            {pin.searchName ? `来自提醒：${pin.searchName}` : '来自提醒'}
            <span className="text-muted-foreground"> · 当前结果中没有此挂单</span>
          </span>
          <button
            type="button"
            aria-label="关闭提醒挂单"
            title="关闭"
            onClick={(e) => {
              e.stopPropagation();
              pin.onDismiss();
            }}
            className="inline-flex size-5 shrink-0 items-center justify-center rounded-sm text-muted-foreground hover:bg-primary/15 hover:text-foreground"
          >
            <X className="size-3" />
          </button>
        </div>
      )}
      {/* 1. Header */}
      <header className="flex gap-3 p-3 pb-2">
        <div className="flex h-[76px] w-16 shrink-0 items-center justify-center rounded-md border border-border/50">
          <ListingThumb
            listing={listing}
            className="size-full border-0 bg-none shadow-none"
            artClassName="max-h-[68px] max-w-14"
          />
        </div>
        <div className="min-w-0 flex-1">
          <h3
            className={cn('truncate text-sm font-bold uppercase tracking-[0.08em]', itemNameColor(item))}
            title={item.name}
          >
            {item.name}
          </h3>
          {subtitle && <div className="truncate text-xs text-muted-foreground">{subtitle}</div>}
          <div className="mt-1.5 flex flex-wrap gap-1">
            {quality && <span className={cn(pill, 'border-border/70', itemNameColor(item))}>{quality}</span>}
            {item.socket_count > 0 && (
            <span className={cn(pill, 'border-border/70 text-muted-foreground')}>{`${item.socket_count} 孔`}</span>
            )}
            {item.corrupted && <span className={cn(pill, 'border-border/70 text-q-corrupted')}>已腐化</span>}
            {item.is_ethereal && <span className={cn(pill, 'border-border/70 text-muted-foreground')}>无形</span>}
            {item.item_level > 0 && (
              <span className={cn(pill, 'border-border/70 text-muted-foreground')}>{`ilvl ${item.item_level}`}</span>
            )}
            <AddAllModsButton
              item={item}
              label="筛选所有属性"
              className={cn(
                pill,
                'cursor-pointer gap-1 border-dashed border-border/70 text-muted-foreground hover:border-border hover:text-foreground',
              )}
            />
          </div>
        </div>
        <div className="flex max-w-[40%] shrink-0 flex-col items-end gap-1 text-right">
          <span
            className={cn(
              'max-w-full truncate font-bold tabular-nums',
              price ? 'text-xl text-foreground' : 'text-sm text-foreground',
            )}
            title={listing.price || undefined}
          >
            {price ?? (listing.price || '未标价')}
          </span>
          {price && listing.price && (
            <span className="max-w-full truncate text-[11px] text-muted-foreground"
              title={listing.price}>
              {`备注：“${listing.price}”`}
            </span>
          )}
          <DealBadge deal={deal} />
        </div>
      </header>

      {/* 2. Stats strip */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-border/50 px-3 py-1.5 text-xs">
        {item.damage?.two_handed && (
          <span className="inline-flex items-center gap-1.5">
            <Swords className="size-3.5 text-muted-foreground" />
            双手伤害
            <span className="font-semibold tabular-nums">{`${item.damage.two_handed.minimum} – ${item.damage.two_handed.maximum}`}</span>
          </span>
        )}
        {item.damage?.one_handed && (
          <span className="inline-flex items-center gap-1.5">
            <Swords className="size-3.5 text-muted-foreground" />
            单手伤害
            <span className="font-semibold tabular-nums">{`${item.damage.one_handed.minimum} – ${item.damage.one_handed.maximum}`}</span>
          </span>
        )}
        {item.defense && item.defense.total > 0 && (
          <span className="inline-flex items-center gap-1.5">
            <Shield className="size-3.5 text-muted-foreground" />
            防御 <span className="font-semibold tabular-nums">{item.defense.total}</span>
          </span>
        )}
        <span className="flex gap-1">
          {req?.level > 0 && <span className={cn(pill, 'border-border/70')}>{`Lvl ${req.level}`}</span>}
          {req?.strength > 0 && <span className={cn(pill, 'border-border/70')}>{`Str ${req.strength}`}</span>}
          {req?.dexterity > 0 && <span className={cn(pill, 'border-border/70')}>{`Dex ${req.dexterity}`}</span>}
        </span>
      </div>

      {/* 3. Mods, in game order (runes, keys etc. have none: no empty block) */}
      {(model.mods.length > 0 || pseudoKeys.length > 0) && (
        <div className="space-y-px border-t border-border/50 px-1.5 py-1.5">
          {model.mods.map((m, i) => (
            <ModLine
              key={`${m.mod.name}-${i}`}
              item={item}
              line={m}
              groups={model.groups}
              groupListings={groupListings}
              matched={statKeys.some((key) => modMatchesStatKey(m.mod, key))}
              highlighted={hovered !== null && m.sources.some((s) => s.group === hovered)}
              onHoverGroup={setHovered}
            />
          ))}
          {pseudoKeys.length > 0 && (
            <div className="flex flex-wrap gap-1 px-1.5 pt-1">
              {pseudoKeys.map((key) => (
                <span
                  key={key}
                  title={statWithValue(key, row.pseudo[key] ?? 0)}
                  className="inline-flex h-5 items-center gap-0.5 rounded-sm bg-muted/60 px-1.5 text-[11px] tabular-nums text-muted-foreground"
                >
                  <Sigma className="size-3" />
                  {statWithValue(key, row.pseudo[key] ?? 0, { short: true })}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 4. Socketed (only when a socketed item lists a bonus; the `Nos` pill covers the rest) */}
      {model.showSockets && (
        <SocketSection
          item={item}
          groupListings={groupListings}
          groups={model.groups}
          socketGroups={model.socketGroups}
          emptySockets={model.emptySockets}
          hovered={hovered}
          onHover={setHovered}
          groupHr={groupHr}
        />
      )}

      {/* 5. Footer: a quiet strip like the chat trader card's action bar */}
      <footer className="flex flex-wrap items-center gap-x-3 gap-y-1.5 border-t border-border/60 bg-foreground/[0.045] px-3 py-1.5 text-xs">
        <span className="flex min-w-0 flex-1 flex-wrap items-center gap-x-2.5 gap-y-1">
          {/* Who: presence + account, with the character they're on */}
          <span className="inline-flex h-6 min-w-0 items-center gap-1.5 rounded-full border border-border/60 bg-muted/30 pl-2 pr-2.5">
            <OnlineDots listing={listing} />
            {account && <span className="truncate font-semibold text-foreground">{account}</span>}
            {item.character_id && (
              <>
                <span aria-hidden
                  className="h-3 w-px bg-border" />
                <span
                  className="inline-flex min-w-0 items-center gap-1 text-muted-foreground"
                  title={`游戏角色：${item.character_id}`}
                >
                  <Gamepad2
                    className={cn('size-3 shrink-0', isUserOnlineIngame(listing.user_last_ingame) && 'text-success')}
                  />
                  <span className="truncate">{item.character_id}</span>
                </span>
              </>
            )}
          </span>
          {/* When / where */}
          <span className="inline-flex items-center gap-2 text-[11px] text-muted-foreground">
            <span className="inline-flex items-center gap-1 tabular-nums"
              title="最近更新">
              <Clock className="size-3" />
              {listingAge(listing)}
            </span>
            <span className="rounded border border-border/60 px-1.5 py-px text-[10px] font-medium uppercase tracking-wide">
              {`${listing.is_hardcore ? '专家模式' : '普通模式'} · ${listing.is_ladder ? '天梯' : '非天梯'}`}
            </span>
          </span>
        </span>
        <span className="flex shrink-0 items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className={cn(iconActionClass, favorite && 'text-destructive hover:text-destructive')}
            aria-pressed={favorite}
            aria-label={favorite ? '取消收藏（F）' : '添加收藏（F）'}
            title={favorite ? '取消收藏（F）' : '添加收藏（F）'}
            onClick={() => onToggleFavorite(listing)}
          >
            <HeartPop favorite={favorite} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className={iconActionClass}
            aria-label="联系卖家"
            title="联系卖家"
            onClick={actions.openDm}
          >
            <MessageSquare className="size-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className={iconActionClass}
            aria-label="在 Project Diablo 2 网站查看"
            title="在 Project Diablo 2 网站查看"
            onClick={actions.openWebsite}
          >
            <ExternalLink className="size-3.5" />
          </Button>
          {!archived && <WhisperButton actions={actions}
            dense />}
          {!archived && (
            <OfferButton
              api={api}
              listing={listing}
              onWebsite={actions.openWebsite}
              dense
              openNonce={command?.action === 'offer' ? command.nonce : undefined}
              ensureFresh={actions.ensureFresh}
            />
          )}
        </span>
      </footer>
    </article>
  );
});

/** The favorite heart; it pops once (scale bounce) when turned on, not on mount. */
function HeartPop({ favorite }: { favorite: boolean }) {
  const [pops, setPops] = useState(0);
  const [last, setLast] = useState(favorite);
  if (favorite !== last) {
    setLast(favorite);
    if (favorite) setPops((n) => n + 1);
  }
  return (
    <motion.span
      key={pops}
      className="inline-flex"
      initial={false}
      animate={pops ? { scale: [1, 1.35, 1] } : undefined}
      transition={{ duration: DUR.slow, ease: EASE_OUT }}
    >
      <Heart className={cn('size-3.5', favorite && 'fill-current')} />
    </motion.span>
  );
}

/**
 * What sockets add to a line, compact: `413 + 235` (or `80 corr + 20`, or `from`) and an overlapping stack of the
 * contributing socketables' icons; the tooltip lists each source with its amount.
 */
function SourceSuffix({
  line,
  groups,
  groupListings,
  onHoverGroup,
}: {
  line: CardMod;
  groups: SocketGroup[];
  groupListings: MarketListingEntry[];
  onHoverGroup: (g: number | null) => void;
}) {
  const { mod, own, ownKind, sources, socketOnly } = line;
  const added = sources.reduce((sum, s) => sum + s.amount, 0);
  const ownText = own === null ? '' : ownKind === 'corruption' ? `${formatStat(own)} corr` : formatStat(own);
  const icons = sources.flatMap((s) => groups[s.group].items.map(() => s.group)).slice(0, MAX_STACK_ICONS);
  const ownLabel =
    own === null || socketOnly
      ? null
      : ownKind === 'roll'
        ? `${formatStat(own)} roll [${mod.min} – ${mod.max}]`
        : ownKind === 'corruption'
          ? `${formatStat(own)} corruption`
          : `${formatStat(own)} item`;

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span
          tabIndex={0}
          className="ml-1.5 inline-flex items-center gap-1 rounded-sm align-middle text-xs font-normal text-muted-foreground outline-none tabular-nums focus-visible:ring-2 focus-visible:ring-ring/60"
        >
          {socketOnly ? 'from' : `${ownText} + ${formatStat(added)}`}
          <span className="inline-flex items-center pl-0.5">
            {icons.map((g, i) => (
              <span
                key={i}
                className={cn(i > 0 && '-ml-1')}
                onMouseEnter={() => onHoverGroup(g)}
                onMouseLeave={() => onHoverGroup(null)}
              >
                <SocketIcon listing={groupListings[g]} />
              </span>
            ))}
          </span>
        </span>
      </TooltipTrigger>
      <TooltipContent side="top"
        align="start"
        className="space-y-1 text-[11px]">
        {ownLabel && <div className="text-muted-foreground">{ownLabel}</div>}
        {sources.map((s) => {
          const group = groups[s.group];
          return (
            <div key={s.group}
              className="flex items-center gap-1.5">
              <SocketIcon listing={groupListings[s.group]}
                className="size-4" />
              <span className={groupNameColor(group)}>
                {`${group.items.length > 1 ? `${group.items.length} × ` : ''}${shortName(group.name)}`}
              </span>
              <span className="ml-auto pl-3 font-semibold tabular-nums">{`+${formatStat(s.amount)}`}</span>
            </div>
          );
        })}
      </TooltipContent>
    </Tooltip>
  );
}

function ModLine({
  item,
  line,
  groups,
  groupListings,
  matched,
  highlighted,
  onHoverGroup,
}: {
  item: ItemDetail;
  line: CardMod;
  groups: SocketGroup[];
  groupListings: MarketListingEntry[];
  matched: boolean;
  highlighted: boolean;
  onHoverGroup: (g: number | null) => void;
}) {
  const { mod, own, sources, socketOnly } = line;
  const hasRange = mod.min !== undefined && mod.max !== undefined && mod.min !== mod.max;
  const split = sources.length > 0 && (socketOnly || own !== null);

  return (
    <ModMenu
      mod={mod}
      item={item}
      className={cn(
        'relative flex min-h-6 items-center gap-2 overflow-hidden rounded-sm px-2 py-0.5 text-[13px] transition-colors duration-(--dur-fast)',
        highlighted && 'bg-muted/60',
      )}
    >
      {matched && <span aria-hidden
        className="absolute inset-y-0.5 left-0 w-[3px] rounded-full bg-primary" />}
      <span
        className={cn(
          'relative min-w-0 flex-1',
          line.corrupted ? 'text-q-corrupted' : 'text-q-magic',
          matched && 'font-semibold',
        )}
      >
        {localizePd2Text(line.label)}
        {hasRange && <span className="text-muted-foreground">{` [${mod.min} – ${mod.max}]`}</span>}
        {line.perLevel && <span className="text-muted-foreground"> 每级</span>}
        {split && (
          <SourceSuffix line={line}
            groups={groups}
            groupListings={groupListings}
            onHoverGroup={onHoverGroup} />
        )}
      </span>
      {matched && <span className="relative shrink-0 text-[11px] text-primary">✓ 已筛选</span>}
    </ModMenu>
  );
}

function SocketSection({
  item,
  groupListings,
  groups,
  socketGroups,
  emptySockets,
  hovered,
  onHover,
  groupHr,
}: {
  /** The listed item (its pseudo totals feed the line menus). */
  item: ItemDetail;
  /** The card's listing with each group's item swapped in (art + prices). */
  groupListings: MarketListingEntry[];
  groups: SocketGroup[];
  socketGroups: number[];
  emptySockets: number;
  hovered: number | null;
  onHover: (g: number | null) => void;
  groupHr: (g: number) => number | null;
}) {
  const filled = socketGroups.length;
  const values = groups.map((_, i) => groupHr(i));
  const total = values.length > 0 && values.every((v) => v !== null) ? values.reduce((s, v) => s + (v ?? 0), 0) : null;
  const columns = Math.min(Math.max(groups.length, 1), 3);
  return (
    <section className="border-t border-border/50 px-3 py-2"
      onMouseLeave={() => onHover(null)}>
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{`已镶嵌（${filled}）`}</span>
        <span className="flex items-center gap-1">
          {socketGroups.map((g, socket) => (
            <span
              key={socket}
              onMouseEnter={() => onHover(g)}
              className={cn(
                'flex size-6 items-center justify-center rounded-full border bg-muted/30 transition-[border-color,transform] duration-(--dur-fast) ease-out motion-safe:hover:scale-110',
                hovered === g ? 'border-foreground/50' : 'border-border',
              )}
              title={groups[g].name}
            >
              <ListingThumb
                listing={groupListings[g]}
                className="size-full rounded-full border-0 bg-none shadow-none"
                artClassName="max-h-[18px] max-w-[18px]"
              />
            </span>
          ))}
          {Array.from({ length: emptySockets }, (_, i) => (
            <span key={`empty-${i}`}
              className="size-6 rounded-full border border-dashed border-border" />
          ))}
        </span>
        {emptySockets > 0 && (
          <span className="text-[11px] text-muted-foreground">{`${emptySockets} 个空孔`}</span>
        )}
        {total !== null && total > 0 && (
          <span className="ml-auto text-[11px] tabular-nums text-muted-foreground">{`镶嵌物估值约 ${formatStat(total)} HR`}</span>
        )}
      </div>
      {groups.length > 0 && (
        <div className="mt-1.5 grid gap-1.5"
          style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}>
          {groups.map((group, g) => (
            <div
              key={group.key}
              onMouseEnter={() => onHover(g)}
              className={cn(
                'min-w-0 rounded-md border border-border/60 px-2 py-1 text-[11px] transition-colors duration-(--dur-fast)',
                hovered === g && 'bg-muted/50',
              )}
            >
              <div className="flex items-center gap-1.5">
                <SocketIcon listing={groupListings[g]}
                  className="size-7" />
                <span className={cn('truncate text-[12px] font-semibold', groupNameColor(group))}>
                  {group.items.length > 1 ? `${group.items.length} × ${group.name}` : group.name}
                </span>
                {values[g] !== null && (
                  <span className="ml-auto shrink-0 tabular-nums text-muted-foreground">{`~${formatStat(values[g] ?? 0)} HR`}</span>
                )}
              </div>
              {group.subtitle && <div className="pl-[26px] text-[10px] text-muted-foreground">{group.subtitle}</div>}
              {group.lines.length > 0 && (
                <div className="mt-0.5 ml-[9px] space-y-px border-l border-border/60 pl-2">
                  {group.lines.map((l, i) => {
                    const text = (
                      <>
                        {l.each}
                        {l.total && <span className="text-muted-foreground">{` each · ${l.total} total`}</span>}
                      </>
                    );
                    const lineClass = 'truncate rounded-sm text-[11px] text-q-magic/80';
                    // Flag-only lines (Zod's Indestructible) have no mod to filter on
                    const mod = group.mods[i];
                    return mod ? (
                      <ModMenu key={i}
                        mod={mod}
                        item={item}
                        socketLine
                        className={lineClass}>
                        {text}
                      </ModMenu>
                    ) : (
                      <div key={i}
                        className={lineClass}>
                        {text}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
