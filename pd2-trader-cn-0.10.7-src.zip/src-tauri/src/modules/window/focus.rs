//! Game focus context, shared by every platform.
//!
//! Overlay panels and global hotkeys follow the *game context* rather than raw OS focus:
//! - Diablo II in the foreground starts the game context.
//! - Focus moving from Diablo onto our overlay keeps it, so typing into a panel doesn't hide the rest.
//! - Any other application in the foreground ends it. Our overlay focused from outside the game
//!   (sign-in or What's New at startup, Settings opened from the tray) is therefore not game context.
//! - No foreground window at all (Windows reports this mid-activation) is ignored instead of being read
//!   as a focus loss, which used to bounce every listener false -> true.

use serde::Serialize;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use tauri::{AppHandle, Emitter};

use super::{diablo_running, foreground, initialize_foreground_monitoring};

/// Webview event carrying the game context (`bool`); `is_diablo_focused` returns the same value.
pub const FOCUS_EVENT: &str = "diablo-focus-changed";
/// Webview event carrying the raw `Foreground` on every foreground change (Unknown skipped). Panels that close
/// when the user leaves them use it: it also sees leaving the game while the overlay never had focus.
pub const FOREGROUND_EVENT: &str = "foreground-changed";

/// Who owns the OS foreground.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum Foreground {
    /// The Diablo II window.
    Diablo,
    /// One of our own windows (the overlay), whether or not Diablo II is running.
    OwnWindow,
    /// Another application.
    Other,
    /// No foreground window; carries no information.
    Unknown,
}

/// The owner as the game context sees it: our window only keeps the game context while Diablo II is
/// running; without the game it is just another app.
pub fn game_owner(owner: Foreground, diablo_running: bool) -> Foreground {
    match owner {
        Foreground::OwnWindow if !diablo_running => Foreground::Other,
        owner => owner,
    }
}

/// Game context after `foreground` takes the OS foreground while the context is `current`.
pub fn next_game_context(current: bool, foreground: Foreground) -> bool {
    match foreground {
        Foreground::Diablo => true,
        Foreground::Other => false,
        Foreground::OwnWindow | Foreground::Unknown => current,
    }
}

static GAME_CONTEXT: AtomicBool = AtomicBool::new(false);
/// Serializes read-update-emit so concurrent foreground callbacks can't emit out of order.
static TRANSITION: Mutex<()> = Mutex::new(());

/// True while the user is in the game: Diablo II is in front, or one of our windows was focused from it.
pub fn is_game_context() -> bool {
    GAME_CONTEXT.load(Ordering::SeqCst)
}

/// Seeds the game context from the current foreground, emits it, then re-evaluates on every
/// foreground change; `on_change` runs after each emitted value (initial one included).
pub fn initialize_diablo_focus_monitoring(
    app_handle: AppHandle,
    on_change: Box<dyn Fn(bool) + Send + 'static>,
) {
    let update = move |force_emit: bool| {
        let _transition = TRANSITION
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let owner = foreground();
        if owner != Foreground::Unknown {
            let _ = app_handle.emit(FOREGROUND_EVENT, owner);
        }
        let current = GAME_CONTEXT.load(Ordering::SeqCst);
        let next = next_game_context(current, game_owner(owner, diablo_running()));
        if next == current && !force_emit {
            return;
        }
        GAME_CONTEXT.store(next, Ordering::SeqCst);
        let _ = app_handle.emit(FOCUS_EVENT, next);
        on_change(next);
    };

    update(true);
    initialize_foreground_monitoring(move || update(false));
}

#[cfg(test)]
mod tests {
    use super::Foreground::*;
    use super::*;

    fn run(start: bool, steps: &[Foreground]) -> Vec<bool> {
        steps
            .iter()
            .scan(start, |ctx, fg| {
                *ctx = next_game_context(*ctx, *fg);
                Some(*ctx)
            })
            .collect()
    }

    #[test]
    fn own_window_focused_from_the_game_keeps_the_game_context() {
        assert_eq!(
            run(false, &[Diablo, OwnWindow, OwnWindow, Diablo]),
            [true, true, true, true]
        );
    }

    #[test]
    fn own_window_focused_from_outside_the_game_is_not_game_context() {
        // Startup sign-in / What's New, or Settings opened from the tray while in another app
        assert_eq!(run(false, &[OwnWindow]), [false]);
        assert_eq!(
            run(false, &[Diablo, Other, OwnWindow]),
            [true, false, false]
        );
    }

    #[test]
    fn leaving_to_another_app_ends_the_game_context() {
        assert_eq!(run(false, &[Diablo, OwnWindow, Other]), [true, true, false]);
    }

    #[test]
    fn missing_foreground_window_does_not_flip_the_context() {
        assert_eq!(run(false, &[Diablo, Unknown, Diablo]), [true, true, true]);
        assert_eq!(run(false, &[Other, Unknown]), [false, false]);
    }

    #[test]
    fn our_window_is_only_game_context_while_diablo_runs() {
        assert_eq!(game_owner(OwnWindow, true), OwnWindow);
        // Settings opened from the tray without the game: reported as ours, but not game context
        assert_eq!(game_owner(OwnWindow, false), Other);
        assert_eq!(run(true, &[game_owner(OwnWindow, false)]), [false]);
        for owner in [Diablo, Other, Unknown] {
            assert_eq!(game_owner(owner, false), owner);
            assert_eq!(game_owner(owner, true), owner);
        }
    }
}
