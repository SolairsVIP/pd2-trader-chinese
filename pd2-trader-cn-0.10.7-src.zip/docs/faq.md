---
title: FAQ
---

- **Where can I change character settings, such as hardcore or ladder?**

  Navigate to the system tray icon, right-click it and select "Settings". There you can change your character settings.

- **Is this app approved by PD2? Can I get banned for using it?**

  The app is offically approved by the PD2 team. It uses official PD2 OAuth for authentication and is approved for use. You will not be banned for using it as it does not modify the game in any way, it only reads the text from the game window.

- **Is this app affiliated with Official Project Diablo 2 (PD2)?**

  No, this app is not affiliated with the Official Project Diablo 2 team. It is an independent project.
